package com.example.conronaPatients;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConronaPatientsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConronaPatientsApplication.class, args);
	}

}
