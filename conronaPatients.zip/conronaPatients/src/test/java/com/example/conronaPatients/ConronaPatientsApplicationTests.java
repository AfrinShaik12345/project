package com.example.conronaPatients;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConronaPatientsApplicationTests {

	@Test
	void contextLoads() {
	}

}
